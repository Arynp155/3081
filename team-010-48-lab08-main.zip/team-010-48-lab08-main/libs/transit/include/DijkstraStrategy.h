#ifndef DIJKSTRASTRATEGY_H_
#define DIJKSTRASTRATEGY_H_

#include "PathStrategy.h"
#include "routing/dijkstra.h"
/**
 * @class DijkstraStrategy
 * @brief inherits from PathStrategy and creates an object to move using the
 * DijkstraStrategy
 */
class DijkstraStrategy : public PathStrategy {
 public:
  /**
   * @param start Vector3: starting location
   * @param destination Vector3:  destination for the object
   * @param graph const routing::IGraph*: graph object for the route.
   * @brief Construstor create object with parameter values
   */
  DijkstraStrategy(Vector3 start, Vector3 destination,
                   const routing::IGraph* graph);
};

#endif
