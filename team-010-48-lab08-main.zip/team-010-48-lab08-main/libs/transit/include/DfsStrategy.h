#ifndef DFSSTRATEGY_H_
#define DFSSTRATEGY_H_

#include "PathStrategy.h"
#include "routing/depth_first_search.h"
/**
 * @class DfsStrategy
 * @brief inherits from PathStrategy and creates an object to move using the
 * DfsStrategy
 */
class DfsStrategy : public PathStrategy {
 public:
  /**
   * @param start Vector3: starting location
   * @param destination Vector3:  destination for the object
   * @param graph const routing::IGraph*: graph object for the route.
   * @brief Construstor create object with parameter values
   */
  DfsStrategy(Vector3 start, Vector3 destination, const routing::IGraph* graph);
};

#endif
