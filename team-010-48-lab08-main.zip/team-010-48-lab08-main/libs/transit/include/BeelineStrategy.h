#ifndef BEELINESTRATEGY_H_
#define BEELINESTRATEGY_H_

#include "PathStrategy.h"
/**
 * @class BeelineStrategy
 * @brief inherits from PathStrategy and creates an object to move using the
 * BeelineStrategy
 */
class BeelineStrategy : public PathStrategy {
 public:
  /**
   * @param start Vector3, start location of object
   * @param destination Vector3
   * @brief Constructor for Beeline creates object with beeling strategy.
   */
  BeelineStrategy(Vector3 start, Vector3 destination);
};

#endif