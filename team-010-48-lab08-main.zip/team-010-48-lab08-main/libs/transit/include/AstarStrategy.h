#ifndef ASTARSTRATEGY_H_
#define ASTARSTRATEGY_H_

#include "PathStrategy.h"
#include "routing/astar.h"
/**
 * @class AstarStrategy
 * @brief inherits from PathStrategy and creates an object to move using the
 * AstarStrategy
 */
class AstarStrategy : public PathStrategy {
 public:
  /**
   * @param start Vector3: starting location
   * @param destination Vector3:  destination for the object
   * @param graph const routing::IGraph*: graph object for the route.
   * @brief Construstor create object with parameter values
   */
  AstarStrategy(Vector3 start, Vector3 destination,
                const routing::IGraph* graph);
};

#endif
