#include "IEntity.h"
/**
 * @class IStrategy
 * @brief Base parent class for a strategy establishes virtual functions move
 * and isComplete for sub classes.
 */
class IStrategy {
 public:
  /**
   * @param entity IEntity* takes in an entity object to move location.
   * @param dt double takes in double to move the object.
   * @brief This changes the position of the entity and changes it based on
   * direction speed and parameter dt.
   */
  virtual void move(IEntity* entity, double dt) const;
  /**
   * @brief checks to see if the object has reached the final destination
   */
  virtual bool isComplete() const;
  virtual void move(IEntity* entity, double dt) = 0;
  virtual bool isCompleted() = 0;
};