#ifndef PATHSTRATEGY_H_
#define PATHSTRATEGY_H_

#include "IStrategy.h"
#include "math/vector3.h"

/**
 * @class PathStrategy
 * @brief inherits from IStrategy, parent class for other Strategy classes
 */
class PathStrategy : public IStrategy {
 protected:
  std::vector<std::vector<float>> path;
  int index;

 public:
  /**
   * @brief constructor with no parameters makes a PathStrategy Object
   */
  PathStrategy();
  /**
   * @param path std::vector<std::vector<float>> path for the object to follow
   * @brief constructor creates object and sets path to parameter
   */
  PathStrategy(std::vector<std::vector<float>> path);
  /**
   * @param entity IEntity* takes in an entity object to move location.
   * @param dt double takes in double to move the object.
   * @brief This changes the position of the entity and changes it based on
   * direction speed and parameter dt.
   */
  void move(IEntity* entity, double dt);
  /**
   * @brief checks to see if the object has reached the final destination
   */
  bool isCompleted();
};

#endif
