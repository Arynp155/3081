#include "PathStrategy.h"

PathStrategy::PathStrategy() {}

PathStrategy::PathStrategy(std::vector<std::vector<float>> path) {
  this->path = path;
  this->index = 0;
}

void PathStrategy::move(IEntity* entity, double dt) {
  if (!isCompleted()) {
    // for( int i = 0; i < 3; i++){
    //     std::cout << "Path[index].at " << i <<  std::endl;
    //     std::cout << path[index].at(i) << std::endl;
    // }
    Vector3 indCurr =
        Vector3(path[index].at(0), path[index].at(1), path[index].at(2));
    Vector3 indPlusOne = Vector3(path[index + 1].at(0), path[index + 1].at(1),
                                 path[index + 1].at(2));

    Vector3 direction = (indPlusOne - entity->getPosition()).unit();

    Vector3 my_position =
        entity->getPosition() + (direction * entity->getSpeed() * dt);
    entity->setPosition(my_position);
    entity->setDirection(direction);

    if (entity->getPosition().dist(indPlusOne) < 1.0) {
      this->index++;
    }
  }
}

bool PathStrategy::isCompleted() {
  if (index == path.size() - 1) {
    return true;
  }
  return false;
}
