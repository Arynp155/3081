#include "DijkstraStrategy.h"

DijkstraStrategy::DijkstraStrategy(Vector3 start, Vector3 destination,
                                   const routing::IGraph* graph) {
  std::vector<float> s = {(float)start.x, (float)start.y, (float)start.z};
  std::vector<float> d = {(float)destination.x, (float)destination.y,
                          (float)destination.z};
  this->path = graph->GetPath(s, d, routing::Dijkstra::Default());
  this->index = 0;
}
