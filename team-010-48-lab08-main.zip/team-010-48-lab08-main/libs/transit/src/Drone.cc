#define _USE_MATH_DEFINES
#include "Drone.h"

#include <cmath>
#include <limits>

#include "AstarStrategy.h"
#include "BeelineStrategy.h"
#include "BfsStrategy.h"
#include "DfsStrategy.h"
#include "DijkstraStrategy.h"
#include "Package.h"
#include "SimulationModel.h"

Drone::Drone(JsonObject& obj) : IEntity(obj) { available = true; }

Drone::~Drone() {}

void Drone::getNextDelivery() {
  if (model && model->scheduledDeliveries.size() > 0) {
    package = model->scheduledDeliveries.front();
    model->scheduledDeliveries.pop_front();

    if (package) {
      available = false;
      pickedUp = false;

      Vector3 packagePosition = package->getPosition();
      Vector3 finalDestination = package->getDestination();
    }
  }
}

void Drone::update(double dt) {
  if (available) {
    getNextDelivery();
  } else {
    if (pickedUp) {
      // Implement movemnt pattern in package to go to dropoff
      strat->move(this, dt);
      package->setPosition(this->position);
      package->setDirection(this->direction);

      if (strat->isCompleted()) {
        pickedUp = false;
        available = true;
        // free(strat);
        strat = nullptr;
        package = NULL;
      }

    } else {
      // Beeline towards package
      strat = new BeelineStrategy(this->position, package->getPosition());
      strat->move(this, dt);
      if (strat->isCompleted()) {
        pickedUp = true;
        // free(strat);
        strat = nullptr;
        // Assign new strat after getting package
        if (package->getStrategyName() == "astar") {
          std::cout << "picks astar" << std::endl;
          strat = new AstarStrategy(this->position, package->getDestination(),
                                    model->getGraph());
        } else if (package->getStrategyName() == "dfs") {
          strat = new DfsStrategy(this->position, package->getDestination(),
                                  model->getGraph());
        } else if (package->getStrategyName() == "bfs") {
          strat = new BfsStrategy(this->position, package->getDestination(),
                                  model->getGraph());
        } else if (package->getStrategyName() == "dijkstra") {
          strat = new DijkstraStrategy(
              this->position, package->getDestination(), model->getGraph());
        }
      }
    }
  }
}
