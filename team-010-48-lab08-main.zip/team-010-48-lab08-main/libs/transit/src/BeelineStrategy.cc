#include "BeelineStrategy.h"

BeelineStrategy::BeelineStrategy(Vector3 start, Vector3 destination) {
  this->path = {
      {(float)start.x, (float)start.y, (float)start.z},
      {(float)destination.x, (float)destination.y, (float)destination.z}};
  this->index = 0;
}
